package MyTCP;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.channels.NonWritableChannelException;

public class Server
{
	public static void main(String[] args)
	{
		
		StartListen();
	}
	
	/**
	 * ���ü����Ķ˿ں�
	 */
	public static void StartListen()
	{
		int port = 10001;
		createTCP(port);
	}
	
	/**
	 * 
	 * @param port
	 * @param address
	 */
	public static void createTCP(int port)
	{
		try
		{
			ServerSocket serverSocket = new ServerSocket(port);
			System.out.println("server list on 127.0.0.1:10001");
			
			Socket socket = serverSocket.accept();
			BufferedReader bufrea = null;
			BufferedWriter bufw = null;
			BufferedReader bufSys = null;
			
			while (true)
			{
				bufrea = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				System.out.println("���������յ��Ŀͻ��˵���ϢΪ �� " + bufrea.readLine());
				
				bufSys = new BufferedReader(new InputStreamReader(System.in));
				bufw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
				
				bufw.write(bufSys.readLine());
				bufw.newLine();
				bufw.flush();
			}
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally 
		{
			
			
			
		}
	}
}


//            // ��ȡ�ͻ��˵�������Ϣ
//            String str = in.readLine();
//            
//            input = new BufferedReader(new InputStreamReader(System.in));
//            
//            System.out.println("��������ʾ-->�ͻ����������ݣ�" + str);
//            
//            out = new PrintWriter(socket.getOutputStream(),true);
//            // ������������ͻ���
//            // out.println("hehe");
//            String info = input.readLine();
//            
//            out.println(info);

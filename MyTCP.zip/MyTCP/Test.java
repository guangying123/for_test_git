package MyTCP;

public class Test 
{

	public static void main(String[] args)
	{
		Thread thread1 = new Thread(new Client());
		thread1.start();
		
		Thread thread2 = new Thread(new Client());
		thread2.start();
		
		Thread thread3 = new Thread(new Client());
		thread3.start();
	}
}

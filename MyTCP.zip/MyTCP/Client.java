package MyTCP;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class Client implements Runnable 
{
	@Override
	public void run() {
		// TODO Auto-generated method stub
		start();
	}

	public static void start()
	{
		System.out.println("This is Thread : " + Thread.currentThread().getName());
		
		int port  = 10001;
		try 
		{
			Socket socket = new Socket("127.0.0.1", port);
			BufferedWriter bufw = null;
			BufferedReader bufr = null;
			BufferedReader bufSys = null;
			
			while (true)
			{
				bufw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
				bufSys = new BufferedReader(new InputStreamReader(System.in));
				bufw.write(bufSys.readLine());
				bufw.newLine();
				bufw.flush();
				
				System.out.println("Now is in : " + Thread.currentThread().getName());
				bufr = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				System.out.println(bufr.readLine());
			}
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
}
